import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Car, Clock, Phone, User, MapPin } from 'lucide-react';

interface VehicleInParking {
  plate: string;
  ownerName: string;
  ownerPhone: string;
  vehicleType: string;
  entryTime: Date;
  spotNumber: number;
}

interface ActiveVehiclesProps {
  vehicles: VehicleInParking[];
  onSelectVehicle?: (vehicle: VehicleInParking) => void;
}

export default function ActiveVehicles({ vehicles, onSelectVehicle }: ActiveVehiclesProps) {
  const formatDuration = (entryTime: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - entryTime.getTime();
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const getVehicleTypeColor = (type: string) => {
    const colors = {
      sedan: 'bg-blue-500/10 text-blue-700 border-blue-200',
      suv: 'bg-green-500/10 text-green-700 border-green-200',
      hatchback: 'bg-purple-500/10 text-purple-700 border-purple-200',
      pickup: 'bg-orange-500/10 text-orange-700 border-orange-200',
      coupe: 'bg-pink-500/10 text-pink-700 border-pink-200'
    };
    return colors[type as keyof typeof colors] || colors.sedan;
  };

  const getDurationColor = (entryTime: Date) => {
    const now = new Date();
    const diffHours = (now.getTime() - entryTime.getTime()) / (1000 * 60 * 60);
    
    if (diffHours >= 8) return 'text-destructive';
    if (diffHours >= 4) return 'text-accent-foreground';
    return 'text-muted-foreground';
  };

  if (vehicles.length === 0) {
    return (
      <Card className="bg-gradient-card shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Car className="h-5 w-5 text-muted-foreground" />
            Vehículos en el Parqueadero
          </CardTitle>
          <CardDescription>No hay vehículos actualmente en el parqueadero</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Car className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              El parqueadero está vacío. ¡Listo para recibir vehículos!
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-card shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Car className="h-5 w-5 text-primary" />
          Vehículos en el Parqueadero
        </CardTitle>
        <CardDescription>
          {vehicles.length} vehículo{vehicles.length !== 1 ? 's' : ''} actualmente registrado{vehicles.length !== 1 ? 's' : ''}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {vehicles.map((vehicle) => (
            <div 
              key={vehicle.plate}
              className="p-4 border rounded-lg hover:shadow-card transition-all duration-200 bg-card/50"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 space-y-3">
                  {/* Información principal */}
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2">
                      <Car className="h-4 w-4 text-primary" />
                      <span className="font-bold text-lg">{vehicle.plate}</span>
                    </div>
                    <Badge className={getVehicleTypeColor(vehicle.vehicleType)}>
                      {vehicle.vehicleType}
                    </Badge>
                    <div className="flex items-center gap-1 text-sm">
                      <MapPin className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">Espacio #{vehicle.spotNumber}</span>
                    </div>
                  </div>

                  {/* Información del propietario */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>{vehicle.ownerName}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{vehicle.ownerPhone}</span>
                    </div>
                  </div>

                  {/* Información de tiempo */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">
                        Ingreso: {vehicle.entryTime.toLocaleString()}
                      </span>
                    </div>
                    <div className={`text-sm font-medium ${getDurationColor(vehicle.entryTime)}`}>
                      {formatDuration(vehicle.entryTime)}
                    </div>
                  </div>
                </div>

                {/* Acciones */}
                {onSelectVehicle && (
                  <div className="ml-4">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => onSelectVehicle(vehicle)}
                    >
                      Procesar Salida
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Resumen al final */}
        <div className="mt-6 pt-4 border-t">
          <div className="flex justify-between items-center text-sm text-muted-foreground">
            <span>Total de vehículos: {vehicles.length}</span>
            <span>Espacios disponibles: {64 - vehicles.length}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}