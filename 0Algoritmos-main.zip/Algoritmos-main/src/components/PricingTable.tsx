import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DollarSign, Clock, Info } from 'lucide-react';

export default function PricingTable() {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-card shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="h-5 w-5 text-primary" />
            Tabla de Precios
          </CardTitle>
          <CardDescription>
            Tarifas del parqueadero EasyParking - Universidad de Antioquia
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Tarifa Principal */}
            <div className="space-y-4">
              <div className="bg-primary/10 p-6 rounded-lg border border-primary/20">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-primary" />
                    <h3 className="text-lg font-semibold">Tarifa por Hora</h3>
                  </div>
                  <Badge variant="secondary">Principal</Badge>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">
                    {formatCurrency(3000)}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Por cada hora o fracción
                  </p>
                </div>
              </div>
            </div>

            {/* Información Adicional */}
            <div className="space-y-4">
              <div className="bg-muted/50 p-6 rounded-lg">
                <div className="flex items-center gap-2 mb-4">
                  <Info className="h-5 w-5 text-accent" />
                  <h3 className="text-lg font-semibold">Información</h3>
                </div>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    Solo vehículos automóviles
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    64 espacios disponibles
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    Tiempo mínimo: 1 hora
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                    Cobro por hora completa o fracción
                  </li>
                </ul>
              </div>
            </div>
          </div>

          {/* Ejemplos de Costos */}
          <div className="mt-6">
            <h4 className="text-md font-semibold mb-4">Ejemplos de Costos</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { time: '1 hora', cost: 3000 },
                { time: '2 horas', cost: 6000 },
                { time: '4 horas', cost: 12000 },
                { time: '8 horas', cost: 24000 }
              ].map((example) => (
                <div key={example.time} className="bg-card p-4 rounded-lg border text-center">
                  <div className="text-sm text-muted-foreground mb-1">{example.time}</div>
                  <div className="text-lg font-bold text-accent">
                    {formatCurrency(example.cost)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Nota Importante */}
          <div className="mt-6 p-4 bg-accent/10 border border-accent/20 rounded-lg">
            <div className="flex items-start gap-2">
              <Info className="h-4 w-4 text-accent mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-medium text-accent mb-1">Nota Importante:</p>
                <p className="text-muted-foreground">
                  Los precios están sujetos a cambios según las políticas de la Universidad de Antioquia. 
                  El tiempo se calcula desde el momento de ingreso hasta la salida, redondeando hacia arriba 
                  a la hora completa más cercana.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}