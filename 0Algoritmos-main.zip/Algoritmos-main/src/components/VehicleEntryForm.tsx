import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Car, Clock, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface VehicleEntry {
  plate: string;
  ownerName: string;
  ownerPhone: string;
  vehicleType: string;
  entryTime: Date;
  spotNumber: number;
}

interface VehicleEntryFormProps {
  onVehicleEntry: (vehicle: VehicleEntry) => void;
  availableSpots: number;
}

export default function VehicleEntryForm({ onVehicleEntry, availableSpots }: VehicleEntryFormProps) {
  const [formData, setFormData] = useState({
    plate: '',
    ownerName: '',
    ownerPhone: '',
    vehicleType: 'sedan'
  });

  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (availableSpots <= 0) {
      toast({
        title: "Parqueadero lleno",
        description: "No hay espacios disponibles en este momento",
        variant: "destructive"
      });
      return;
    }

    if (!formData.plate || !formData.ownerName || !formData.ownerPhone) {
      toast({
        title: "Campos requeridos",
        description: "Por favor complete todos los campos obligatorios",
        variant: "destructive"
      });
      return;
    }

    const spotNumber = 65 - availableSpots;
    const newEntry: VehicleEntry = {
      ...formData,
      entryTime: new Date(),
      spotNumber
    };

    onVehicleEntry(newEntry);
    
    setFormData({
      plate: '',
      ownerName: '',
      ownerPhone: '',
      vehicleType: 'sedan'
    });

    toast({
      title: "Vehículo registrado",
      description: `Placa ${formData.plate} asignada al espacio ${spotNumber}`,
      variant: "default"
    });
  };

  return (
    <Card className="bg-gradient-card shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Car className="h-5 w-5 text-primary" />
          Ingreso de Vehículo
        </CardTitle>
        <CardDescription>
          Registre el ingreso de un nuevo vehículo al parqueadero
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="plate">Placa del Vehículo *</Label>
              <Input
                id="plate"
                value={formData.plate}
                onChange={(e) => setFormData({ ...formData, plate: e.target.value.toUpperCase() })}
                placeholder="ABC123"
                className="transition-all focus:shadow-card"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="vehicleType">Tipo de Vehículo</Label>
              <Select 
                value={formData.vehicleType} 
                onValueChange={(value) => setFormData({ ...formData, vehicleType: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sedan">Sedán</SelectItem>
                  <SelectItem value="suv">SUV</SelectItem>
                  <SelectItem value="hatchback">Hatchback</SelectItem>
                  <SelectItem value="pickup">Pickup</SelectItem>
                  <SelectItem value="coupe">Coupé</SelectItem>
                  <SelectItem value="convertible">Convertible</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ownerName">Nombre del Propietario *</Label>
              <Input
                id="ownerName"
                value={formData.ownerName}
                onChange={(e) => setFormData({ ...formData, ownerName: e.target.value })}
                placeholder="Juan Pérez"
                className="transition-all focus:shadow-card"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="ownerPhone">Teléfono *</Label>
              <Input
                id="ownerPhone"
                value={formData.ownerPhone}
                onChange={(e) => setFormData({ ...formData, ownerPhone: e.target.value })}
                placeholder="300 123 4567"
                className="transition-all focus:shadow-card"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
            <Clock className="h-4 w-4 text-primary" />
            <span className="text-sm">
              Hora de ingreso: {new Date().toLocaleString()}
            </span>
          </div>

          <div className="flex items-center gap-2 p-3 bg-secondary/20 rounded-lg">
            <User className="h-4 w-4 text-secondary" />
            <span className="text-sm">
              Espacios disponibles: <strong>{availableSpots}/64</strong>
            </span>
          </div>

          <Button 
            type="submit" 
            variant="success" 
            size="lg" 
            className="w-full"
            disabled={availableSpots <= 0}
          >
            {availableSpots > 0 ? 'Registrar Ingreso' : 'Parqueadero Lleno'}
          </Button>
        </form>
        
        <div className="mt-6 space-y-3">
          <h3 className="text-lg font-semibold text-foreground">Tipos de Vehículos</h3>
          <img 
            src="/tipos-carros/17865981-338f-4402-a352-e0ef704b0069.png" 
            alt="Tipos de vehículos: Sedán, Coupé, Hatchback, SUV, Convertible, Pickup" 
            className="w-full rounded-lg shadow-md"
          />
          <p className="text-sm text-muted-foreground">
            Seleccione el tipo de vehículo que mejor describe su automóvil
          </p>
        </div>
      </CardContent>
    </Card>
  );
}