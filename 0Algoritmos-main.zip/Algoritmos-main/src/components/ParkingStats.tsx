import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Car, Clock, DollarSign, Users, Zap, TrendingUp } from 'lucide-react';

interface VehicleInParking {
  plate: string;
  ownerName: string;
  ownerPhone: string;
  vehicleType: string;
  entryTime: Date;
  spotNumber: number;
}

interface DailyStats {
  totalEntries: number;
  totalExits: number;
  totalRevenue: number;
  averageStayTime: number;
}

interface ParkingStatsProps {
  vehicles: VehicleInParking[];
  dailyStats: DailyStats;
}

export default function ParkingStats({ vehicles, dailyStats }: ParkingStatsProps) {
  const occupiedSpots = vehicles.length;
  const availableSpots = 64 - occupiedSpots;
  const occupancyRate = (occupiedSpots / 64) * 100;

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('es-CO', {
      style: 'currency',
      currency: 'COP',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const getOccupancyColor = () => {
    if (occupancyRate >= 90) return 'text-destructive';
    if (occupancyRate >= 70) return 'text-accent-foreground';
    return 'text-secondary';
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Ocupación actual */}
      <Card className="bg-gradient-card shadow-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Ocupación Actual</CardTitle>
          <Car className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{occupiedSpots}/64</div>
          <div className="flex items-center space-x-2">
            <div className={`text-xs ${getOccupancyColor()}`}>
              {occupancyRate.toFixed(1)}% ocupado
            </div>
          </div>
          <div className="mt-2 w-full bg-muted rounded-full h-2">
            <div 
              className="bg-gradient-primary h-2 rounded-full transition-all duration-500"
              style={{ width: `${occupancyRate}%` }}
            />
          </div>
        </CardContent>
      </Card>

      {/* Espacios disponibles */}
      <Card className="bg-gradient-card shadow-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Espacios Disponibles</CardTitle>
          <Zap className="h-4 w-4 text-secondary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-secondary">{availableSpots}</div>
          <p className="text-xs text-muted-foreground">
            {availableSpots > 0 ? 'Listo para nuevos vehículos' : 'Parqueadero lleno'}
          </p>
          <div className="mt-2">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Libre</span>
              <span>Ocupado</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Ingresos del día */}
      <Card className="bg-gradient-card shadow-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Ingresos Hoy</CardTitle>
          <DollarSign className="h-4 w-4 text-accent" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-accent">
            {formatCurrency(dailyStats.totalRevenue)}
          </div>
          <p className="text-xs text-muted-foreground">
            {dailyStats.totalExits} vehículos facturados
          </p>
        </CardContent>
      </Card>

      {/* Total entradas del día */}
      <Card className="bg-gradient-card shadow-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Entradas Hoy</CardTitle>
          <TrendingUp className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-primary">{dailyStats.totalEntries}</div>
          <p className="text-xs text-muted-foreground">
            Vehículos ingresados
          </p>
        </CardContent>
      </Card>

      {/* Tiempo promedio de estadía */}
      <Card className="bg-gradient-card shadow-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Tiempo Promedio</CardTitle>
          <Clock className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {formatTime(dailyStats.averageStayTime)}
          </div>
          <p className="text-xs text-muted-foreground">
            Tiempo de estadía promedio
          </p>
        </CardContent>
      </Card>

      {/* Usuarios activos */}
      <Card className="bg-gradient-card shadow-card">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Usuarios Activos</CardTitle>
          <Users className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-primary">{occupiedSpots}</div>
          <p className="text-xs text-muted-foreground">
            En el parqueadero ahora
          </p>
        </CardContent>
      </Card>
    </div>
  );
}