import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CarTaxiFront, Clock, DollarSign, Timer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface VehicleInParking {
  plate: string;
  ownerName: string;
  ownerPhone: string;
  vehicleType: string;
  entryTime: Date;
  spotNumber: number;
}

interface VehicleExitFormProps {
  vehicles: VehicleInParking[];
  onVehicleExit: (plate: string) => void;
}

export default function VehicleExitForm({ vehicles, onVehicleExit }: VehicleExitFormProps) {
  const [searchPlate, setSearchPlate] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleInParking | null>(null);
  const { toast } = useToast();

  const HOURLY_RATE = 3000; // Tarifa por hora en pesos

  const calculateParkingTime = (entryTime: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - entryTime.getTime();
    const diffHours = Math.ceil(diffMs / (1000 * 60 * 60)); // Redondear hacia arriba
    return Math.max(1, diffHours); // Mínimo 1 hora
  };

  const calculateCost = (hours: number) => {
    return hours * HOURLY_RATE;
  };

  const formatDuration = (entryTime: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - entryTime.getTime();
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const handleSearch = () => {
    if (!searchPlate.trim()) {
      toast({
        title: "Placa requerida",
        description: "Por favor ingrese una placa para buscar",
        variant: "destructive"
      });
      return;
    }

    const vehicle = vehicles.find(v => 
      v.plate.toLowerCase() === searchPlate.toLowerCase().trim()
    );

    if (vehicle) {
      setSelectedVehicle(vehicle);
    } else {
      setSelectedVehicle(null);
      toast({
        title: "Vehículo no encontrado",
        description: `No se encontró el vehículo con placa ${searchPlate}`,
        variant: "destructive"
      });
    }
  };

  const handleExit = () => {
    if (!selectedVehicle) return;

    const hours = calculateParkingTime(selectedVehicle.entryTime);
    const cost = calculateCost(hours);

    onVehicleExit(selectedVehicle.plate);
    
    toast({
      title: "Salida registrada",
      description: `Vehículo ${selectedVehicle.plate} - Total: $${cost.toLocaleString()}`,
      variant: "default"
    });

    setSearchPlate('');
    setSelectedVehicle(null);
  };

  return (
    <Card className="bg-gradient-card shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CarTaxiFront className="h-5 w-5 text-primary" />
          Salida de Vehículo
        </CardTitle>
        <CardDescription>
          Busque un vehículo por placa para registrar su salida
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Búsqueda de vehículo */}
          <div className="space-y-2">
            <Label htmlFor="search-plate">Placa del Vehículo</Label>
            <div className="flex gap-2">
              <Input
                id="search-plate"
                value={searchPlate}
                onChange={(e) => setSearchPlate(e.target.value.toUpperCase())}
                placeholder="ABC123"
                className="transition-all focus:shadow-card"
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button onClick={handleSearch} variant="default">
                Buscar
              </Button>
            </div>
          </div>

          {/* Información del vehículo encontrado */}
          {selectedVehicle && (
            <div className="space-y-4 p-4 bg-muted/50 rounded-lg border-2 border-primary/20">
              <h3 className="font-semibold text-lg text-primary">Vehículo Encontrado</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <strong>Placa:</strong> {selectedVehicle.plate}
                  </div>
                  <div className="flex items-center gap-2">
                    <strong>Propietario:</strong> {selectedVehicle.ownerName}
                  </div>
                  <div className="flex items-center gap-2">
                    <strong>Teléfono:</strong> {selectedVehicle.ownerPhone}
                  </div>
                  <div className="flex items-center gap-2">
                    <strong>Tipo:</strong> {selectedVehicle.vehicleType}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-primary" />
                    <strong>Ingreso:</strong> {selectedVehicle.entryTime.toLocaleString()}
                  </div>
                  <div className="flex items-center gap-2">
                    <Timer className="h-4 w-4 text-secondary" />
                    <strong>Tiempo:</strong> {formatDuration(selectedVehicle.entryTime)}
                  </div>
                  <div className="flex items-center gap-2">
                    <strong>Espacio:</strong> #{selectedVehicle.spotNumber}
                  </div>
                </div>
              </div>

              {/* Cálculo de costo */}
              <div className="mt-4 p-4 bg-gradient-primary rounded-lg text-primary-foreground">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    <span className="text-lg font-semibold">Total a Pagar:</span>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold">
                      ${calculateCost(calculateParkingTime(selectedVehicle.entryTime)).toLocaleString()}
                    </div>
                    <div className="text-sm opacity-90">
                      {calculateParkingTime(selectedVehicle.entryTime)} hora(s) × ${HOURLY_RATE.toLocaleString()}/hora
                    </div>
                  </div>
                </div>
              </div>

              <Button 
                onClick={handleExit} 
                variant="parking" 
                size="lg" 
                className="w-full"
              >
                Registrar Salida y Cobrar
              </Button>
            </div>
          )}

          {/* Lista de vehículos en el parqueadero */}
          {vehicles.length > 0 && (
            <div className="space-y-2">
              <h4 className="font-medium text-foreground">Vehículos en el parqueadero:</h4>
              <div className="max-h-32 overflow-y-auto space-y-1">
                {vehicles.map((vehicle) => (
                  <div 
                    key={vehicle.plate}
                    className="flex justify-between items-center p-2 bg-card rounded border cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => {
                      setSearchPlate(vehicle.plate);
                      setSelectedVehicle(vehicle);
                    }}
                  >
                    <span className="font-medium">{vehicle.plate}</span>
                    <span className="text-sm text-muted-foreground">
                      Espacio #{vehicle.spotNumber}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}