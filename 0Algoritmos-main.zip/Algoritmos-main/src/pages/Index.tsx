import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Car, BarChart3, Users, Settings, Download } from 'lucide-react';
import VehicleEntryForm from '@/components/VehicleEntryForm';
import VehicleExitForm from '@/components/VehicleExitForm';
import ParkingStats from '@/components/ParkingStats';
import ActiveVehicles from '@/components/ActiveVehicles';
import PricingTable from '@/components/PricingTable';
import easyParkingLogo from '@/assets/easyparking-logo.jpg';

interface VehicleInParking {
  plate: string;
  ownerName: string;
  ownerPhone: string;
  vehicleType: string;
  entryTime: Date;
  spotNumber: number;
}

interface DailyStats {
  totalEntries: number;
  totalExits: number;
  totalRevenue: number;
  averageStayTime: number;
}

interface Transaction {
  id: string;
  plate: string;
  ownerName: string;
  entryTime: Date;
  exitTime: Date;
  duration: number;
  cost: number;
  spotNumber: number;
}

const Index = () => {
  const [vehicles, setVehicles] = useState<VehicleInParking[]>([]);
  const [dailyStats, setDailyStats] = useState<DailyStats>({
    totalEntries: 0,
    totalExits: 0,
    totalRevenue: 0,
    averageStayTime: 0
  });
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [activeTab, setActiveTab] = useState('dashboard');

  const HOURLY_RATE = 3000;

  // Cargar datos del localStorage al iniciar
  useEffect(() => {
    const savedVehicles = localStorage.getItem('easyparking-vehicles');
    const savedStats = localStorage.getItem('easyparking-stats');
    const savedTransactions = localStorage.getItem('easyparking-transactions');

    if (savedVehicles) {
      const parsedVehicles = JSON.parse(savedVehicles);
      // Convertir las fechas de string a Date
      const vehiclesWithDates = parsedVehicles.map((v: any) => ({
        ...v,
        entryTime: new Date(v.entryTime)
      }));
      setVehicles(vehiclesWithDates);
    }

    if (savedStats) {
      setDailyStats(JSON.parse(savedStats));
    }

    if (savedTransactions) {
      const parsedTransactions = JSON.parse(savedTransactions);
      const transactionsWithDates = parsedTransactions.map((t: any) => ({
        ...t,
        entryTime: new Date(t.entryTime),
        exitTime: new Date(t.exitTime)
      }));
      setTransactions(transactionsWithDates);
    }
  }, []);

  // Guardar datos en localStorage cuando cambien
  useEffect(() => {
    localStorage.setItem('easyparking-vehicles', JSON.stringify(vehicles));
  }, [vehicles]);

  useEffect(() => {
    localStorage.setItem('easyparking-stats', JSON.stringify(dailyStats));
  }, [dailyStats]);

  useEffect(() => {
    localStorage.setItem('easyparking-transactions', JSON.stringify(transactions));
  }, [transactions]);

  const handleVehicleEntry = (newVehicle: VehicleInParking) => {
    setVehicles(prev => [...prev, newVehicle]);
    setDailyStats(prev => ({
      ...prev,
      totalEntries: prev.totalEntries + 1
    }));
  };

  const calculateParkingTime = (entryTime: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - entryTime.getTime();
    const diffHours = Math.ceil(diffMs / (1000 * 60 * 60));
    return Math.max(1, diffHours);
  };

  const handleVehicleExit = (plate: string) => {
    const vehicle = vehicles.find(v => v.plate === plate);
    if (!vehicle) return;

    const exitTime = new Date();
    const duration = calculateParkingTime(vehicle.entryTime);
    const cost = duration * HOURLY_RATE;

    // Crear transacción
    const transaction: Transaction = {
      id: `${plate}-${Date.now()}`,
      plate: vehicle.plate,
      ownerName: vehicle.ownerName,
      entryTime: vehicle.entryTime,
      exitTime,
      duration,
      cost,
      spotNumber: vehicle.spotNumber
    };

    // Actualizar estados
    setTransactions(prev => [...prev, transaction]);
    setVehicles(prev => prev.filter(v => v.plate !== plate));
    
    // Actualizar estadísticas diarias
    setDailyStats(prev => {
      const newTotalExits = prev.totalExits + 1;
      const newTotalRevenue = prev.totalRevenue + cost;
      
      // Calcular nuevo tiempo promedio
      const allDurations = [...transactions.map(t => t.duration), duration];
      const newAverageStayTime = allDurations.reduce((acc, dur) => acc + dur, 0) / allDurations.length * 60; // en minutos

      return {
        ...prev,
        totalExits: newTotalExits,
        totalRevenue: newTotalRevenue,
        averageStayTime: newAverageStayTime
      };
    });
  };

  const exportToCSV = () => {
    const headers = ['Fecha', 'Placa', 'Propietario', 'Hora Entrada', 'Hora Salida', 'Duración (horas)', 'Costo', 'Espacio'];
    const data = transactions.map(t => [
      t.exitTime.toLocaleDateString(),
      t.plate,
      t.ownerName,
      t.entryTime.toLocaleTimeString(),
      t.exitTime.toLocaleTimeString(),
      t.duration,
      t.cost,
      t.spotNumber
    ]);

    const csvContent = [headers, ...data]
      .map(row => row.join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `easyparking-reporte-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const availableSpots = 64 - vehicles.length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-hero text-primary-foreground shadow-glow">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img 
                src={easyParkingLogo} 
                alt="EasyParking Logo" 
                className="w-16 h-16 rounded-lg shadow-card object-cover"
              />
              <div>
                <h1 className="text-3xl font-bold">EasyParking</h1>
                <p className="text-primary-foreground/80">¡Rápido, sencillo y a tu medida!</p>
                <p className="text-sm text-primary-foreground/70">Universidad de Antioquia - Sistema de Gestión de Parqueadero</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">{availableSpots}/64</div>
              <div className="text-sm text-primary-foreground/80">Espacios disponibles</div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-fit lg:grid-cols-6">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="entry" className="flex items-center gap-2">
              <Car className="h-4 w-4" />
              Ingreso
            </TabsTrigger>
            <TabsTrigger value="exit" className="flex items-center gap-2">
              <Car className="h-4 w-4 rotate-180" />
              Salida
            </TabsTrigger>
            <TabsTrigger value="vehicles" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Vehículos
            </TabsTrigger>
            <TabsTrigger value="pricing" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Precios
            </TabsTrigger>
            <TabsTrigger value="reports" className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Reportes
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6">
            <ParkingStats vehicles={vehicles} dailyStats={dailyStats} />
            <ActiveVehicles vehicles={vehicles.slice(0, 5)} />
          </TabsContent>

          <TabsContent value="entry">
            <VehicleEntryForm 
              onVehicleEntry={handleVehicleEntry}
              availableSpots={availableSpots}
            />
          </TabsContent>

          <TabsContent value="exit">
            <VehicleExitForm 
              vehicles={vehicles}
              onVehicleExit={handleVehicleExit}
            />
          </TabsContent>

          <TabsContent value="vehicles">
            <ActiveVehicles vehicles={vehicles} />
          </TabsContent>

          <TabsContent value="pricing">
            <PricingTable />
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <Card className="bg-gradient-card shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5 text-primary" />
                  Exportar Reportes
                </CardTitle>
                <CardDescription>
                  Descargue un reporte completo de todas las transacciones
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-primary">{transactions.length}</div>
                      <div className="text-sm text-muted-foreground">Transacciones totales</div>
                    </div>
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-secondary">
                        ${dailyStats.totalRevenue.toLocaleString()}
                      </div>
                      <div className="text-sm text-muted-foreground">Ingresos del día</div>
                    </div>
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-accent">{vehicles.length}</div>
                      <div className="text-sm text-muted-foreground">Vehículos activos</div>
                    </div>
                  </div>
                  
                  <Button 
                    onClick={exportToCSV}
                    variant="parking"
                    size="lg"
                    className="w-full"
                    disabled={transactions.length === 0}
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Descargar Reporte CSV
                  </Button>
                  
                  {transactions.length === 0 && (
                    <p className="text-center text-muted-foreground text-sm">
                      No hay transacciones para exportar
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Historial de transacciones recientes */}
            {transactions.length > 0 && (
              <Card className="bg-gradient-card shadow-card">
                <CardHeader>
                  <CardTitle>Transacciones Recientes</CardTitle>
                  <CardDescription>
                    Últimas {Math.min(10, transactions.length)} transacciones completadas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {transactions
                      .slice(-10)
                      .reverse()
                      .map((transaction) => (
                        <div 
                          key={transaction.id}
                          className="flex justify-between items-center p-3 bg-card rounded border"
                        >
                          <div>
                            <div className="font-medium">{transaction.plate}</div>
                            <div className="text-sm text-muted-foreground">
                              {transaction.ownerName} - Espacio #{transaction.spotNumber}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-accent">
                              ${transaction.cost.toLocaleString()}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {transaction.duration}h
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="bg-card border-t py-6 mt-12">
        <div className="container mx-auto px-4 text-center text-muted-foreground">
          <p>© 2024 EasyParking - Universidad de Antioquia</p>
          <p className="text-sm mt-1">
            Desarrollado por: Leibman Andrade, Jhoiner Rodríguez, Wilber Rodríguez
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
